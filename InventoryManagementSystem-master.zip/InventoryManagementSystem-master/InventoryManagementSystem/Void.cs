﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementSystem
{
	public partial class Void : Form
	{
		SqlConnection cn = new SqlConnection();
		SqlCommand cm = new SqlCommand();
		DBConnect dbcon = new DBConnect();
		SqlDataReader dr;
		CancelOrder cancelOrder;
		public Void(CancelOrder cancel)
		{
			InitializeComponent();
			txtUsername.Focus();
			cancelOrder = cancel;
		}

		private void btnVoid_Click(object sender, EventArgs e)
		{
			try
			{
				if(txtUsername.Text == cancelOrder.textBox5.Text)
				{
                     MessageBox.Show("Void by name and cancelled by name are same!.Please void by another person. ","Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}
				string user;
				cn.Open();
				cm = new SqlCommand("Select * From tbUser Where username = @username and password = @password", cn);
				cm.Parameters.AddWithValue("@username", txtUsername.Text);
				cm.Parameters.AddWithValue("@password", txtPass.Text);
				dr = cm.ExecuteReader();
				dr.Read();
				if (dr.HasRows)
				{
					user = dr["username"].ToString();
					dr.Close();
					cn.Close();
					SaveCancelOrder(user);
					if (cancelOrder.cbInventory.Text== "yes") 
					{
						dbcon.ExecuteQuery("UPDATE tbProduct SET qty = qty + " + cancelOrder.udCancelQty.Value + " where pcode= '" + cancelOrder.textBox3.Text + "'");
					}
					dbcon.ExecuteQuery("UPDATE tbCart SET qty = qty + " + cancelOrder.udCancelQty.Value + " where id LIKE  '" + cancelOrder.textBox1.Text + "'");
					MessageBox.Show("Order transaction successfully cancelled!", "Cancel Order", MessageBoxButtons.OK, MessageBoxIcon.Information); 
					this.Dispose();
					cancelOrder.ReloadSoldList();
					cancelOrder.Dispose();
				}
				dr.Close();
				cn.Close() ;
			}
			catch (Exception ex)
			{
				cn.Close();
				MessageBox.Show(ex.Message, "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);

			}
		}

			public void SaveCancelOrder(string user)
			{
			try
			{
				cn.Open();
				cm = new SqlCommand("insert into tbCancel (transno, pcode, price, qty, sdate, voidby, cancelledby, reason, action) values(@transno, @pcode, @price, @qty, @sdate, @voidby, @cancelledby, @reason, @action", cn);
				cm.Parameters.AddWithValue("@transno", cancelOrder.textBox4.Text);
				cm.Parameters.AddWithValue("@pcode", cancelOrder.textBox3.Text);
				cm.Parameters.AddWithValue("@price", double.Parse(cancelOrder.txtPrice.Text));
				cm.Parameters.AddWithValue("@qty", int.Parse(cancelOrder.txtQty.Text));

				cm.Parameters.AddWithValue("@total", DateTime.Now);
				cm.Parameters.AddWithValue("voidby", user);
				cm.Parameters.AddWithValue("@cancelledby", cancelOrder.textBox5.Text);
				cm.Parameters.AddWithValue("@reason", cancelOrder.txtReasons.Text);
				cm.Parameters.AddWithValue("@action", cancelOrder.cbInventory.Text);
				cm.ExecuteNonQuery();
				cn.Close();
			}
			catch (Exception ex) 
			{
			MessageBox.Show(ex.Message, "Error");
			}
			}
		
	}
}
