﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementSystem
{



    public partial class UserAccount : Form
    {

        SqlConnection cn = new SqlConnection();
        SqlCommand cm = new SqlCommand();
        DBConnect dbcon = new DBConnect();
        SqlDataReader dr;
        main Main;
        string username;
        string name;
        string role;
        string accstatus;

        public UserAccount(main mn)
        {
            InitializeComponent();

            cn = new SqlConnection(dbcon.myConnection());
            Main = mn;
            LoadUser();
        }



        public void LoadUser()
        {
            int i = 0;
            dgvu.Rows.Clear();
            cn.Open();
            cm = new SqlCommand("SELECT * FROM tbUser ",cn );
            dr = cm.ExecuteReader();

            while (dr.Read())
            {
                i++;
                dgvu.Rows.Add(i, dr[0].ToString(), dr[3].ToString(), dr[4].ToString(), dr[2].ToString());
            }

            dr.Close();
            cn.Close();
        }



        private void UserAccount_Load(object sender, EventArgs e)
        {
            lblUsername.Text = Main.lblUser.Text;
        }

        private void txtSearch_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgvBrand_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        public void Clear()
        {
            txtName.Clear();
            txtPass.Clear();
            txtRePass.Clear();
            txtUsername.Clear();
            cbRole.Text = "";
            txtUsername.Focus();


        }



        private void btnAccSave_Click(object sender, EventArgs e)
        {


            try

            {

                if (txtPass != txtRePass)
                {
                    MessageBox.Show("Password didnot match!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;



                    cn.Open();
                    cm = new SqlCommand("Insert into tbUser(username, password, role, name ) Values (@username, @password, @role, @name)", cn);

                    cm.Parameters.AddWithValue("@username", txtUsername.Text);
                    cm.Parameters.AddWithValue("@password", txtPass.Text);
                    cm.Parameters.AddWithValue("@role", cbRole.Text);
                    cm.Parameters.AddWithValue("@name", txtName.Text);
                    cm.ExecuteNonQuery();
                    cn.Close();
                    MessageBox.Show("New account has been successful saved", "Save Record", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    Clear();

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Warning");
            }



        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAccCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void metroTabPage2_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnPassSave_Click(object sender, EventArgs e)
        {
            try
            {

                if (txtCurPass.Text != Main._pass)
                {
                    MessageBox.Show("Current password did not match!", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;

                }
                if (txtCurPass.Text != txtRePass2.Text)
                {

                    MessageBox.Show("Confirm new  password did not match!", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;

                }

                dbcon.ExecuteQuery("UPDATE tbUser SET password= '" + txtNpass.Text + "' WHERE username = '" + lblUsername.Text + "'");
                MessageBox.Show("Password has been changed successfully!", "Changed Password", MessageBoxButtons.OK, MessageBoxIcon.Information);



            }
            catch (Exception ex)

            {
                MessageBox.Show(ex.Message, "Error");



            }
        }

        private void btnPassCancel_Click(object sender, EventArgs e)
        {
            CLearCP();

        }

        public void CLearCP()
        {

            txtCurPass.Clear();
            txtNpass.Clear();
            txtRePass2.Clear();
        }

		private void dgvBrand_SelectionChanged(object sender, EventArgs e)
		{
            int i = dgvUser.CurrentRow.Index;
            username = dgvUser[1,i].Value.ToString();
            name = dgvUser[2, i].Value.ToString();
            role = dgvUser[4, i].Value.ToString();
            accstatus = dgvUser[3, i].Value.ToString();


            if(lblUsername.Text == username)
            {
                btnRemove.Enabled = false;
                btnResetPass.Enabled = false;

            }


            else
            {
                btnRemove.Enabled = true;
                btnResetPass.Enabled = true;


            }
		}

		private void dgvUser_CellContentClick(object sender, DataGridViewCellEventArgs e)
		{

		}

		private void btnRemove_Click(object sender, EventArgs e)
		{
            if(MessageBox.Show("You chosse to remove this account from Inventory Management System's user list. \n\n Are you sure you want to remove '" + username + "' \\ '" + role + "'", "UserAccount" , MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                    {

                dbcon.ExecuteQuery("DELETE FROM tbUser WHERE username = '" + username + "'");
                MessageBox.Show("Account has been successdully deleted");
                LoadUser();
            }
		}
	}
}