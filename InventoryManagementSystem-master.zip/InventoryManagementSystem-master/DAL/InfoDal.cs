﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;
namespace DAL
{
    public class InfoDal
    {
        public static void SaveInfo(InfoModel im)
        {
            SqlConnection con = DBHelper.GetConnection();
            con.Open();
            SqlCommand cmd = new SqlCommand("sp_SaveInfo", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", im.Id);
            cmd.Parameters.AddWithValue("@FirstName", im.FirstName);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public static List<InfoModel> GetInfo()
        {

            SqlConnection con = DBHelper.GetConnection();
            con.Open();
            SqlCommand cmd = new SqlCommand("sp_SaveInfo", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader sdr = cmd.ExecuteReader();
            List<InfoModel> info = new List<InfoModel>();
            while (sdr.Read())
            {
                InfoModel infoModel = new InfoModel();
                infoModel.Id =int.Parse(sdr["Id"].ToString());
                infoModel.FirstName =sdr["FirstName"].ToString();
                info.Add(infoModel);
                
            }
            con.Close();
            return info;

        }
    }
}
