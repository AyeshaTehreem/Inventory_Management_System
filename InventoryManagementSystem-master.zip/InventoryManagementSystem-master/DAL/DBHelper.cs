﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace DAL
{
    public class DBHelper
    {

        public static SqlConnection GetConnection()
        {
            SqlConnection conn = new SqlConnection("");
            return conn;
        }
    }
}
